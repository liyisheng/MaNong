/*************************************************************************
	> File Name: ./func.c
	> Author: Comst
	> Mail:750145240@qq.com 
	> Created Time: Sun 01 Feb 2015 05:57:36 PM CST
 ************************************************************************/

#include"my_server.h"
void dispatch_msg(pCLIENT phead, char* msg)
{
	while(phead)
	{
		write(phead ->m_send, msg, strlen(msg));
		phead = phead ->m_next ;
	}
}

