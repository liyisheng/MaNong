/*************************************************************************
	> File Name: client.c
	> Author: Comst
	> Mail:750145240@qq.com 
	> Created Time: Sun 01 Feb 2015 06:04:36 PM CST
 ************************************************************************/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<fcntl.h>
#include<sys/select.h>
#include<sys/time.h>
#define PIPE_PATH "/home/comst/pipe"
#define PIPE_NAME "server.fifo"
int main(int argc, char* argv[])
{
	int fd_server ;
	char path_name[128]="";
	char fifo_name[128] ;
	char msg[1024] ="" ;
	int fd_recv, fd_send ;
	sprintf(path_name, "%s/%s", PIPE_PATH, PIPE_NAME);

	fd_server = open(path_name, O_WRONLY);
	if(fd_server == -1)
	{
		printf("open fail!\n");
		exit(1) ;
	}
	// pid_r.fifo pid_w.fifo
	//
	memset(fifo_name, 0, 128);
	sprintf(fifo_name, "%u_r.fifo", getpid());
	memset(path_name, 0, sizeof(path_name));
	sprintf(path_name, "%s/%s", PIPE_PATH, fifo_name);
	if(-1 == mkfifo(path_name, 0666) )
	{
		printf("mkfif fail: %s\n", path_name);
		exit(1) ;
	}

	printf("%s open\n", path_name);

	memset(fifo_name, 0, 128);
	sprintf(fifo_name, "%u_w.fifo", getpid());
	memset(path_name, 0, sizeof(path_name));
	sprintf(path_name, "%s/%s", PIPE_PATH, fifo_name);
	if(mkfifo(path_name, 0666) == -1 )
	{
		
		printf("mkfif fail: %s\n", path_name);
		exit(1) ;
	}
	printf("%s open\n", path_name);

	printf("mkfifo over!\n");

	sprintf(msg, "%u on\n", getpid());
	printf("msg: %s\n", msg);

	write(fd_server, msg, strlen(msg));

	memset(fifo_name, 0,  128);
	sprintf(fifo_name, "%u_r.fifo", getpid());
	memset(path_name, 0, sizeof(path_name));
	sprintf(path_name, "%s/%s", PIPE_PATH, fifo_name);

	fd_recv = open(path_name, O_RDONLY);

	memset(fifo_name, 0,  128);
	sprintf(fifo_name, "%u_w.fifo", getpid());
	memset(path_name, 0, sizeof(path_name));
	sprintf(path_name, "%s/%s", PIPE_PATH, fifo_name);

	fd_send = open(path_name, O_WRONLY);

	printf("fifo open %d %d\n", fd_send, fd_recv);

	fd_set rd_sets ;
	FD_ZERO(&rd_sets);
	while(1)
	{
		FD_SET(0, &rd_sets);
		FD_SET(fd_recv, &rd_sets);

		select(1024, &rd_sets, NULL, NULL, NULL);

			if(FD_ISSET(0, &rd_sets))
			{
				memset(msg, 0, sizeof(msg)) ;
				sprintf(msg, "from %u: ", getpid());
				read(0, msg + strlen(msg),  1024 - strlen(msg) );
				write(fd_send, msg, strlen(msg));

			}
			if(FD_ISSET(fd_recv, &rd_sets))
			{
				memset(msg, 0, sizeof(msg)) ;
				read(fd_recv, msg, 1024);
				write(1, msg, strlen(msg));
				
			}


	}


	






}
