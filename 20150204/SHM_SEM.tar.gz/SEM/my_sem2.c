/*************************************************************************
	> File Name: my_sem1.c
	> Author: Comst
	> Mail:750145240@qq.com 
	> Created Time: Wed 04 Feb 2015 11:15:22 AM CST
 ************************************************************************/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
void P(int semid) 
{
	struct sembuf my_buf ;
	memset(&my_buf, 0, sizeof(my_buf) );
	my_buf.sem_num = 0 ;
	my_buf.sem_op = -1 ;
	my_buf.sem_flg = SEM_UNDO ;
	semop(semid, &my_buf, 1);
}
void V(int semid)
{
	struct sembuf my_buf ;
	memset(&my_buf, 0, sizeof(my_buf) );
	my_buf.sem_num = 0 ;
	my_buf.sem_op = 1 ;
	my_buf.sem_flg = SEM_UNDO ;
	semop(semid, &my_buf, 1);
	
}
int main(int argc, char* argv[])
{
	key_t my_key = 1234 ;
	int my_sem ;
	my_sem = semget(my_key, 1, 0666 );
	if(my_sem == -1)
	{
		perror("semget");
		exit(1);
	}
	printf(" getval: %d\n", semctl(my_sem, 0, GETVAL ));

	//semctl(my_sem, 0, SETVAL, 1);

	printf("p...!\n");
	P(my_sem) ;
	printf("hello world !\n");
	V(my_sem);




	return 0 ;
}
